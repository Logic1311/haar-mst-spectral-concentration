"""Floating-point diagnostic of the exact Haar model; no asymptotic theorem inferred from samples.
Independent Prim and SciPy/Kruskal comparisons, graph bounds, row energies, and rank-one stars.
All q values reuse the same sampled matrix/tree. No iid-entry replacement.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'; os.environ['OMP_NUM_THREADS']='1'; os.environ['MKL_NUM_THREADS']='1'
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import minimum_spanning_tree
from scipy.integrate import quad
from scipy.special import gammaln, gamma
from pathlib import Path
import csv, json, math, platform, scipy
ROOT=Path(__file__).resolve().parent
QS=(0.5,1.0,1.5)
DIMS=(24,64,160,384)
REPS=16
FAMILIES=('polynomial','rank1','rank3','mixed_half','diffuse_sparse')

def spectrum(n,f):
    if f=='polynomial': return (np.arange(1,n+1)/n)**1.5
    if f=='rank1': return np.r_[1.,np.zeros(n-1)]
    if f=='rank3': return np.r_[np.ones(3),np.zeros(n-3)]
    if f=='mixed_half':
        tail=np.resize(np.array([1.,-1.]),n-1)/np.sqrt(2*(n-1))
        return np.r_[1/np.sqrt(2),tail]
    if f=='diffuse_sparse':
        r=int(np.sqrt(n)); return np.r_[np.ones(r),np.zeros(n-r)]
    raise ValueError(f)

def limit(f,s):
    if f=='rank1': return gamma(1-s)
    if f=='rank3': return 3**s*np.exp(gammaln(3-s)-gammaln(3))
    if f=='mixed_half': return quad(lambda t: (0.5+0.5*t)**(-s)*np.exp(-t),0,np.inf,epsabs=1e-11)[0]
    return 1.

def prim_max(A):
    n=len(A); visited=np.zeros(n,bool); visited[0]=True; best=A[0].copy(); best[0]=-np.inf
    selected=[]
    for _ in range(n-1):
        i=int(np.argmax(best)); selected.append(best[i]); assert not visited[i]
        visited[i]=True; best=np.maximum(best,A[i]); best[visited]=-np.inf
    return np.array(selected)

def g(k,s):
    # Exponential maximum density. Stable near zero and infinity.
    return quad(lambda t: k*t**(-s)*np.exp(-t)*(-np.expm1(-t))**(k-1),0,np.inf,epsabs=1e-9,limit=250)[0]

def main():
    rng=np.random.default_rng(261131583)
    rows=[]; summary=[]; max_tree_error=0.; max_radius_error=0.; count=0
    for n in DIMS:
        k=max(1,min(n-1,int(n/np.log(n)**2)))
        for family in FAMILIES:
            l=spectrum(n,family); l-=l.mean(); v=np.mean(l*l)
            for rep in range(REPS):
                G=(rng.normal(size=(n,n))+1j*rng.normal(size=(n,n)))/np.sqrt(2)
                U,R=np.linalg.qr(G); d=np.diag(R); U*=d/np.abs(d)
                H=U.conj().T@(l[:,None]*U); A=np.abs(H); np.fill_diagonal(A,0.)
                radius2=(A*A).sum(1)
                weights=abs(U)**2
                rad2_ref=(l*l)@weights-(l@weights)**2
                err=float(np.max(np.abs(radius2-rad2_ref))/v); max_radius_error=max(max_radius_error,err)
                assert np.allclose(radius2,rad2_ref,rtol=2e-9,atol=2e-11*v)
                assert np.all(A[np.triu_indices(n,1)]>0)
                e1=prim_max(A)
                # Distinct algorithm: minimum spanning tree of negative strengths.
                e2=-minimum_spanning_tree(csr_matrix(-A)).data
                assert len(e2)==n-1
                err=float(np.max(np.abs(np.sort(e1)-np.sort(e2)))/np.max(e1)); max_tree_error=max(max_tree_error,err)
                assert np.allclose(np.sort(e1),np.sort(e2),rtol=2e-10,atol=1e-14)
                count+=1
                for q in QS:
                    s=q/2; scale=(v*np.log(n))**s/n**(1+s)
                    M=(e1**(-q)).sum(); b=A.max(1)**(-q)
                    lower=(n-1)/n*b.sum(); upper=(A[k:,:k].max(1)**(-q)).sum()+(A[1:k,0]**(-q)).sum()
                    assert lower<=M*(1+1e-10) and M<=upper*(1+1e-10)
                    if family=='rank1':
                        amp=np.abs(U[0,:]); j=int(np.argmax(amp)); star=((amp[np.arange(n)!=j]*amp[j])**(-q)).sum()
                        assert abs(star/M-1)<2e-8
                    c=np.mean((radius2/v)**(-s))
                    rows.append(dict(n=n,family=family,rep=rep,q=q,k=k,mst=float(scale*M),row_mean=float(c),lower=float(scale*lower),hub_upper=float(scale*upper),target=float(limit(family,s))))
            for q in QS:
                s=q/2; a=[r for r in rows if r['n']==n and r['family']==family and r['q']==q]
                x=np.array([r['mst'] for r in a]); c=np.array([r['row_mean'] for r in a]);
                p=np.sort(l*l/(n*v))[::-1]; exact=None
                if family in ('rank1','rank3','diffuse_sparse'):
                    r={'rank1':1,'rank3':3,'diffuse_sparse':int(np.sqrt(n))}[family]
                    exact=(v**s)*np.exp(gammaln(r-s)+gammaln(n-r-s)-gammaln(n-2*s)-gammaln(r)-gammaln(n-r)+gammaln(n))
                m=n-1; fac=np.exp(gammaln(m)-gammaln(m-s))*np.log(n)**s/n**(1+s)
                ratio_low=fac*(n-1)*g(m,s); ratio_up=fac*((n-k)*g(k,s)+(k-1)*gamma(1-s))
                summary.append(dict(n=n,family=family,q=q,reps=REPS,k=k,pmax=float(p[0]),mean=float(x.mean()),se=float(x.std(ddof=1)/np.sqrt(REPS)),row_mean=float(c.mean()),row_exact=None if exact is None else float(exact),ratio_lower=float(ratio_low),ratio_upper=float(ratio_up),limit=float(limit(family,s))))
            print(n,family,'PASS',flush=True)
    with open(ROOT/'haar_samples.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    out={'seed':261131583,'dimensions':DIMS,'replicates_per_dimension_and_family':REPS,'spectra':FAMILIES,'unique_matrices':count,'nested_q_checks':len(rows),'max_normalized_radius_discrepancy':max_radius_error,'max_normalized_tree_discrepancy':max_tree_error,'versions':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},'precision':'floating-point, not exact or proof','summary':summary}
    (ROOT/'haar_summary.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PASS', count,'Haar matrices;',len(rows),'nested cost checks; max radius error',max_radius_error,'max tree discrepancy',max_tree_error)
if __name__=='__main__': main()
