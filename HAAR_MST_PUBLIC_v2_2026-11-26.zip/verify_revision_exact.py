"""Exact finite checks for the v2 cut-codimension and bottleneck theorems.
These are finite arithmetic checks, not verification of Haar tube asymptotics.
"""
from collections import Counter
from itertools import product, combinations
from fractions import Fraction as F
from pathlib import Path
import json, random, sys
import sympy as sp

SEED=261131584
rng=random.Random(SEED)

def parts(n, lo=1):
    if n==0:
        yield ()
    else:
        for a in range(lo,n+1):
            for b in parts(n-a,a): yield (a,)+b

def exact_cut_counts(m):
    n=sum(m); best=[n*n+1]*(n+1); total=0
    for r in product(*(range(a+1) for a in m)):
        k=sum(r)
        if not 0<k<n: continue
        c=k*(n-k)-sum(a*(b-a) for a,b in zip(r,m))
        assert c==sum(r[i]*(m[j]-r[j]) for i in range(len(m)) for j in range(len(m)) if i!=j)
        assert c>=n-max(m), (m,r,c)
        best[k]=min(best[k],c); total+=1
    gains=sorted((a-1-2*j for a in m for j in range(a)),reverse=True)
    g=0
    for k in range(1,n):
        g+=gains[k-1]
        assert best[k]==k*(n-k)-g
        assert best[k]==best[n-k]
    assert min(best[1:n])==best[1]==n-max(m)
    return best[1:n], total

def dp_cut_counts(m):
    n=sum(m); dp={0:0}
    for a in m:
        nxt={}
        for k,v in dp.items():
            for r in range(a+1):
                t=k+r; w=v+r*(a-r)
                nxt[t]=max(nxt.get(t,-1),w)
        dp=nxt
    return [k*(n-k)-dp[k] for k in range(1,n)]

def labelled_counts(m):
    n=sum(m); colors=[i for i,a in enumerate(m) for _ in range(a)]
    best=[n*n+1]*(n+1); cnt=0
    for k in range(1,n):
        for cut in combinations(range(n),k):
            s=set(cut); c=sum(colors[i]!=colors[j] for i in s for j in range(n) if j not in s)
            best[k]=min(best[k],c);cnt+=1
    return best[1:n],cnt

patterns=0; tuples=0; graph_patterns=0; graph_subsets=0; distinct_k=0
for n in range(2,13):
    for m in parts(n):
        if len(m)==1:continue
        best,count=exact_cut_counts(m);assert best==dp_cut_counts(m)
        patterns+=1;tuples+=count;distinct_k+=n-1
        if n<=8:
            label,count=labelled_counts(m);assert best==label
            graph_patterns+=1;graph_subsets+=count
print(f'CUT_PARTITIONS {patterns}; CUT_ALLOCATIONS {tuples}; CUT_SIZE_OPTIMA {distinct_k}; LABELLED_GRAPH_PATTERNS {graph_patterns}; LABELLED_SUBSETS {graph_subsets}')

# Independent exact matrix identities for rational real / Gaussian-rational projections.
# A random full column rank matrix spans a subspace, so P=A(A*A)^-1 A* is exact.
# These test the key algebra and norm comparison; no eigenvalue solver is used.
def frob2(A):
    return sp.simplify(sum(sp.re(x)**2+sp.im(x)**2 for x in A))

def block_diag_mask(A,colors):
    return sp.Matrix(A.rows,A.cols,lambda i,j:A[i,j] if colors[i]==colors[j] else 0)

matrix_cases=0
for complex_field in (False,True):
    for n in range(2,7):
        for rep in range(4):
            k=rng.randrange(1,n)
            while True:
                A=sp.Matrix(n,k,lambda i,j:sp.Integer(rng.randrange(-2,3))+(sp.I*rng.randrange(-2,3) if complex_field else 0))
                gram=A.conjugate().T*A
                if gram.det()!=0:break
            P=sp.simplify(A*gram.inv()*A.conjugate().T)
            assert sp.simplify(P*P-P)==sp.zeros(n)
            # non-scalar block spectrum (including repeated eigenvalues)
            colors=[0,1]+[rng.randrange(3) for _ in range(n-2)];rng.shuffle(colors)
            H=sp.diag(*colors)
            Q=block_diag_mask(P,colors); E=P-Q
            assert sp.simplify(Q-Q*Q-block_diag_mask(E*E,colors))==sp.zeros(n)
            C=H*P-P*H; J=(sp.eye(n)-P)*H*P
            assert frob2(C)==2*frob2(J)
            assert frob2(E)<=frob2(C) # distinct eigenvalue gaps are >=1
            assert frob2(Q-Q*Q)<=frob2(E)**2
            matrix_cases+=1
print(f'EXACT_PROJECTION_CASES {matrix_cases}')

# Exact scalar rounding certificate, including the tie at 1/2.
rounding_cases=0
for d in range(1,101):
    for a in range(d+1):
        x=F(a,d);r=int(x>F(1,2));assert abs(x-r)<=2*x*(1-x);rounding_cases+=1
print(f'ROUNDING_GRID_CASES {rounding_cases} (grid, not universal proof)')

# Test the sharp cut-to-cost bounds on fresh integer coupling graphs.
# Kruskal maximizes coupling magnitudes, and an independent Prim implementation
# minimizes the inverse costs; exact Fraction arithmetic in both.
def kruskal(A):
    n=len(A); p=list(range(n)); edges=[]
    def find(i):
        while p[i]!=i:i=p[i]
        return i
    for w,i,j in sorted(((A[i][j],i,j) for i in range(n) for j in range(i+1,n)),reverse=True):
        a,b=find(i),find(j)
        if a!=b:p[a]=b;edges.append((w,i,j))
        if len(edges)==n-1:break
    return edges

def prim(A,q):
    n=len(A); seen={0};cost=F(0)
    while len(seen)<n:
        w,i,j=min((F(1,A[i][j]**q),i,j) for i in seen for j in range(n) if j not in seen)
        seen.add(j);cost+=w
    return cost

graphs=0; qchecks=0; cut_checks=0
for n in range(2,9):
    for rep in range(12):
        A=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):A[i][j]=A[j][i]=rng.randrange(1,20)
        Bs=[]
        for mask in range(1,1<<(n-1)):
            s={i for i in range(n) if mask>>i&1}
            Bs.append(max(A[i][j] for i in s for j in range(n) if j not in s))
        tau=min(Bs); cut_checks+=len(Bs)
        edges=kruskal(A);assert min(w for w,i,j in edges)==tau
        for q in (1,2,3):
            mst=sum((F(1,w**q) for w,i,j in edges),F(0));assert mst==prim(A,q)
            rec=sum((F(1,max(A[i][:i])**q) for i in range(1,n)),F(0))
            root_min=sum((F(1,max(A[i])**q) for i in range(n)),F(0))*F(n-1,n)
            assert F(1,tau**q)<=mst<=(n-1)*F(1,tau**q)
            assert root_min<=mst<=rec
            qchecks+=1
        graphs+=1
print(f'FRESH_GRAPHS {graphs}; Q_COMPARISONS {qchecks}; CUTS_ENUMERATED {cut_checks}')

result=dict(seed=SEED, python=sys.version.split()[0],sympy=sp.__version__,multiplicity_partitions=patterns,allocations=tuples,cut_size_optima=distinct_k,independent_labelled_graph_patterns=graph_patterns,labelled_cut_subsets=graph_subsets,exact_projection_cases=matrix_cases,rounding_grid_cases=rounding_cases,fresh_graphs=graphs,nested_q_checks=qchecks,cut_enumerations=cut_checks,status='PASS',scope='Integer and rational identities and graph bounds only; not the Haar tube theorem or large-n convergence.')
Path(__file__).with_name('revision_exact_results.json').write_text(json.dumps(result,indent=2)+'\n')
print('REVISION_EXACT_PASS')
