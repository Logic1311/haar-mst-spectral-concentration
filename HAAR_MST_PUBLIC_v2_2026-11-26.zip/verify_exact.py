"""Exact deterministic checks; not a proof of the asymptotic theorem."""
from itertools import product, combinations
from fractions import Fraction as F
import random, json
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def trees(n):
    # Prüfer decoding (complete enumeration of all labelled trees).
    for code in product(range(n), repeat=n-2):
        deg=[1]*n
        for x in code: deg[x]+=1
        edges=[]
        for x in code:
            v=next(i for i,d in enumerate(deg) if d==1)
            edges.append((v,x)); deg[v]-=1; deg[x]-=1
        edges.append(tuple(i for i,d in enumerate(deg) if d==1))
        yield edges

def kruskal(w):
    n=len(w); parent=list(range(n)); total=F(0); ct=0
    def find(x):
        while parent[x]!=x: x=parent[x]
        return x
    for a,i,j in sorted((w[i][j],i,j) for i in range(n) for j in range(i)):
        x,y=find(i),find(j)
        if x!=y: parent[x]=y; total+=a; ct+=1
    assert ct==n-1
    return total

def run():
    rng=random.Random(261131583)
    counts={'arbitrary_rational_graphs':0,'product_weight_graphs':0,'weighted_variances':0,'root_bounds':0,'hub_tree_bounds':0,'exhaustively_enumerated_trees':0}
    records=[]
    for n in range(2,7):
        tr=list(trees(n))
        assert len(tr)==n**(n-2)
        for case in range(16):
            w=[[F(0)]*n for _ in range(n)]
            if case<8:
                for i,j in combinations(range(n),2): w[i][j]=w[j][i]=F(rng.randrange(1,31),rng.randrange(1,15))
                counts['arbitrary_rational_graphs']+=1
            else:
                a=[F(rng.randrange(1,20),rng.randrange(1,20)) for _ in range(n)]
                for i,j in combinations(range(n),2): w[i][j]=w[j][i]=1/(a[i]*a[j])
                counts['product_weight_graphs']+=1
            best=min(sum(w[i][j] for i,j in edges) for edges in tr)
            counts['exhaustively_enumerated_trees']+=len(tr)
            assert best==kruskal(w)
            b=[min(w[i][j] for j in range(n) if j!=i) for i in range(n)]
            for r in range(n):
                assert sum(b)-b[r]<=best
                counts['root_bounds']+=1
            assert F(n-1,n)*sum(b)<=best
            for k in range(1,n):
                for K in combinations(range(n),k):
                    r=K[0]; upper=sum(min(w[i][j] for j in K) for i in range(n) if i not in K)+sum(w[j][r] for j in K[1:])
                    assert best<=upper
                    counts['hub_tree_bounds']+=1
            if case>=8:
                r=max(range(n),key=a.__getitem__)
                assert best==sum(w[i][r] for i in range(n) if i!=r)
            records.append({'n':n,'case':case,'mst':str(best),'row_lower':str(F(n-1,n)*sum(b))})
    for n in range(2,33):
        for _ in range(20):
            weights=[rng.randrange(1,25) for _ in range(n)]; p=[F(x,sum(weights)) for x in weights]
            l=[F(rng.randrange(-30,31),rng.randrange(1,10)) for _ in p]
            if len(set(l))==1: l[-1]+=1
            var=sum(w*x*x for w,x in zip(p,l))-sum(w*x for w,x in zip(p,l))**2
            pairs=sum(p[i]*p[j]*(l[i]-l[j])**2 for i,j in combinations(range(n),2))
            v=sum(x*x for x in l)/n-(sum(l)/n)**2
            q=[(l[i]-l[j])**2/(n*n*v) for i,j in combinations(range(n),2)]
            assert var==pairs and var>0 and sum(q)==1 and min(q)>=0
            assert var/v==sum(z*n*n*p[i]*p[j] for z,(i,j) in zip(q,combinations(range(n),2)))
            counts['weighted_variances']+=1
    assert F(1,4)-F(2,5)**2==F(9,100)
    out={'counts':counts,'graph_cases':records,'precision':'fractions.Fraction; exact','not_independent_cases':'root bounds and hub choices are nested checks, not new graphs'}
    (ROOT/'exact_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(counts,indent=2));print('PASS; no tolerances')
if __name__=='__main__':run()
