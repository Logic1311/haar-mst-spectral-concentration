#!/usr/bin/env python3
"""Exact rational graph-chart identity; numerical rank-one calibrations."""
import random,json,math
from pathlib import Path
import sympy as S
from scipy.special import betainc, betaln, gammaln
rng=random.Random(451126)
def norm2(A):return S.expand(S.trace(A.H*A))
def logvol(k,n,beta):
    return beta*k*(n-k)/2*math.log(math.pi)+sum(gammaln(beta*j/2)-gammaln(beta*(n-k+j)/2) for j in range(1,k+1))
ct={'real_rational':0,'complex_rational':0,'commuting':0,'beta_calibrations':0,'volume_ratio_calibrations':0};worst=0.;volerr=0.
for beta in [1,2]:
    for t in range(40):
        n=rng.randrange(2,6);k=rng.randrange(1,n);vals=[rng.randrange(-3,4) for _ in range(n)]
        if len(set(vals))==1:vals[-1]+=1
        a,b=vals[:k],vals[k:];gaps=[abs(i-j) for i in vals for j in vals if i!=j];g,G=min(gaps),max(gaps)
        def entry(i,j):
            if t%5==0 and b[i]!=a[j]:return S.Integer(0)
            return S.Rational(rng.randrange(-4,5),rng.randrange(1,5))+(S.I*S.Rational(rng.randrange(-4,5),rng.randrange(1,5)) if beta==2 else 0)
        X=S.Matrix(n-k,k,entry);I=S.eye(k);A=I+X.H*X;C=S.eye(n-k)+X*X.H;Y=I.col_join(X);P=(Y*A.inv()*Y.H).applyfunc(S.expand)
        La=S.diag(*vals);L=S.diag(*b)*X-X*S.diag(*a)
        assert (P*P-P).applyfunc(S.expand)==S.zeros(n) and P==P.H
        F=norm2((S.eye(n)-P)*La*P);B=S.expand(S.trace(A.inv()*L.H*C.inv()*L))
        assert S.simplify(F-B)==0
        off=S.Matrix(n-k,k,lambda i,j:X[i,j] if b[i]!=a[j] else 0);O=norm2(off);r2=norm2(X)
        assert norm2(L)==S.expand(sum((b[i]-a[j])**2*X[i,j]*S.conjugate(X[i,j]) for i in range(n-k) for j in range(k)))
        assert F>=g*g*O/(1+r2)**2 and F<=G*G*O
        if O==0:assert F==0;ct['commuting']+=1
        ct['real_rational' if beta==1 else 'complex_rational']+=1
    for n in range(2,19):
        for k in range(1,n):
            a,b=beta*k/2,beta*(n-k)/2;h=int(2*min(a,b));gap=1.7;eps=gap*1e-5
            x=2*(eps/gap)**2/(1+math.sqrt(1-4*(eps/gap)**2));prob=betainc(a,b,x)+betainc(b,a,x)
            target=gap**(-h)*((1/a if a<=b else 0)+(1/b if b<=a else 0))*math.exp(-betaln(a,b));err=abs(prob/eps**h/target-1);worst=max(worst,err);assert err<1e-3
            terms=[]
            if a<=b:terms.append(logvol(k,n-1,beta))
            if b<=a:terms.append(logvol(k-1,n-1,beta))
            AA=math.exp(h/2*math.log(math.pi)-gammaln(1+h/2)-logvol(k,n,beta)-h*math.log(gap))*sum(math.exp(t) for t in terms)
            err=abs(AA/target-1);volerr=max(volerr,err);assert err<1e-11
            ct['beta_calibrations']+=1;ct['volume_ratio_calibrations']+=1
res={'checks':ct,'max_beta_relative_error':worst,'max_volume_ratio_relative_error':volerr,'note':'Rational checks exact; beta/volume floating-point calibration, not proof.'}
Path('geometry_refinement_results.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2));print('GEOMETRY_REFINEMENT_PASS')
